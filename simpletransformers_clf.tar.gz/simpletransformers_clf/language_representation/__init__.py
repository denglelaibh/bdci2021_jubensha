from simpletransformers.language_representation.representation_model import (
    RepresentationModel,
)
