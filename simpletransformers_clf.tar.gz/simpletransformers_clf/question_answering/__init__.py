from simpletransformers.config.model_args import QuestionAnsweringArgs
from simpletransformers.question_answering.question_answering_model import (
    QuestionAnsweringModel,
)
