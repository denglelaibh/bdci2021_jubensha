将vocab.txt替换为项目之中的vocab.txt
